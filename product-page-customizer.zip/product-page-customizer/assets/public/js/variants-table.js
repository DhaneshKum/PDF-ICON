jQuery(function($) {
    'use strict';

    const debug = (message) => {
        console.log('[PPC Variants]', message);
    };

    class VariantsTable {
        constructor() {
            debug('Initializing VariantsTable');
            
            try {
                // Cache DOM elements
                this.$form = $('.ppc-variants-form');
                debug('Form found:', this.$form.length > 0);
                
                // Only initialize if we find the form
                if (this.$form.length === 0) {
                    debug('No variants form found, initialization stopped');
                    return;
                }

                this.$selectAll = this.$form.find('.select-all');
                this.$variantCheckboxes = this.$form.find('.variant-select');
                this.$submitButton = this.$form.find('.add-to-cart-button');
                this.$messageBox = this.$form.find('.message-box');

                debug('Found elements:', {
                    selectAll: this.$selectAll.length,
                    checkboxes: this.$variantCheckboxes.length,
                    submitButton: this.$submitButton.length
                });

                this.bindEvents();
                
                // Initial state setup
                this.updateSelectAllState();
                this.updateSubmitButton();
                
                debug('Initialization complete');
            } catch (error) {
                console.error('[PPC Variants] Error initializing:', error);
            }
        }

        bindEvents() {
            debug('Binding events');

            // Handle individual variant selection
            this.$variantCheckboxes.on('change', (e) => {
                debug('Checkbox changed');
                const $checkbox = $(e.target);
                const $row = $checkbox.closest('tr');
                const $qtyInput = $row.find('.qty-input');
                const $qtyButtons = $row.find('.qty-btn');
                const isChecked = $checkbox.is(':checked');

                debug('Checkbox state:', {
                    checked: isChecked,
                    row: $row.length > 0,
                    input: $qtyInput.length > 0,
                    buttons: $qtyButtons.length
                });

                if (isChecked) {
                    $qtyInput.prop('disabled', false).val(1);
                    $qtyButtons.prop('disabled', false);
                } else {
                    $qtyInput.prop('disabled', true).val(0);
                    $qtyButtons.prop('disabled', true);
                }

                this.updateSelectAllState();
                this.updateSubmitButton();
            });

            // Handle select all checkbox
            this.$selectAll.on('change', (e) => {
                debug('Select all changed');
                const isChecked = $(e.target).is(':checked');
                
                this.$variantCheckboxes.each((i, checkbox) => {
                    const $checkbox = $(checkbox);
                    const $row = $checkbox.closest('tr');
                    const $qtyInput = $row.find('.qty-input');
                    const $qtyButtons = $row.find('.qty-btn');

                    $checkbox.prop('checked', isChecked);
                    $qtyInput.prop('disabled', !isChecked).val(isChecked ? 1 : 0);
                    $qtyButtons.prop('disabled', !isChecked);
                });

                this.updateSubmitButton();
            });

            // Handle quantity adjustments
            this.$form.on('click', '.qty-btn', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const $button = $(e.currentTarget);
                
                // Don't proceed if button is disabled
                if ($button.prop('disabled')) {
                    debug('Button is disabled, ignoring click');
                    return;
                }
                
                debug('Quantity button clicked:', $button.hasClass('plus') ? 'plus' : 'minus');
                
                const $wrapper = $button.closest('.quantity-wrapper');
                const $input = $wrapper.find('.qty-input');
                
                if ($input.prop('disabled')) {
                    debug('Input is disabled, ignoring click');
                    return;
                }

                const currentVal = parseInt($input.val(), 10) || 0;
                const min = parseInt($input.attr('min'), 10) || 1;
                const max = parseInt($input.attr('max'), 10) || 99;
                let newVal = currentVal;

                debug('Current quantity state:', { currentVal, min, max });

                if ($button.hasClass('plus') && currentVal < max) {
                    newVal = currentVal + 1;
                    debug('Increasing quantity to:', newVal);
                } else if ($button.hasClass('minus') && currentVal > min) {
                    newVal = currentVal - 1;
                    debug('Decreasing quantity to:', newVal);
                } else {
                    debug('Quantity unchanged - at limit:', { currentVal, min, max });
                }

                if (newVal !== currentVal) {
                    $input.val(newVal).trigger('change');
                    this.updateSubmitButton();
                }
            });

            // Handle direct quantity input
            this.$form.on('input change', '.qty-input', (e) => {
                const $input = $(e.target);
                debug('Quantity input changed');
                
                if ($input.prop('disabled')) {
                    debug('Input is disabled, ignoring change');
                    return;
                }

                let val = parseInt($input.val(), 10) || 0;
                const min = parseInt($input.attr('min'), 10) || 1;
                const max = parseInt($input.attr('max'), 10) || 99;

                // Ensure value is within bounds
                val = Math.max(min, Math.min(val, max));
                debug('Validated quantity:', val);
                $input.val(val);

                this.updateSubmitButton();
            });

            // Handle form submission
            this.$form.on('submit', (e) => {
                e.preventDefault();
                e.stopPropagation();
                debug('Form submitted');
                
                if (!this.$submitButton.prop('disabled')) {
                    this.addToCart();
                } else {
                    debug('Submit button is disabled, ignoring submission');
                }
            });

            // Prevent form submission on enter key in quantity inputs
            this.$form.on('keypress', '.qty-input', (e) => {
                if (e.which === 13) {
                    e.preventDefault();
                    e.stopPropagation();
                    debug('Enter key pressed in quantity input, preventing submission');
                    return false;
                }
            });

            debug('Events bound successfully');
        }

        updateSelectAllState() {
            const totalCheckboxes = this.$variantCheckboxes.length;
            const checkedCheckboxes = this.$variantCheckboxes.filter(':checked').length;
            
            debug('Updating select all state:', { total: totalCheckboxes, checked: checkedCheckboxes });
            
            this.$selectAll.prop({
                checked: checkedCheckboxes > 0 && checkedCheckboxes === totalCheckboxes,
                indeterminate: checkedCheckboxes > 0 && checkedCheckboxes < totalCheckboxes
            });
        }

        updateSubmitButton() {
            let hasSelectedItems = false;

            this.$variantCheckboxes.filter(':checked').each((i, checkbox) => {
                const $checkbox = $(checkbox);
                const qty = parseInt($checkbox.closest('tr').find('.qty-input').val(), 10) || 0;
                if (qty > 0) {
                    hasSelectedItems = true;
                    return false; // Break the loop
                }
            });

            debug('Updating submit button state:', { hasSelectedItems });
            this.$submitButton.prop('disabled', !hasSelectedItems);
        }

        showMessage(message, isError = false) {
            debug('Showing message:', { message, isError });
            
            this.$messageBox
                .removeClass('success error')
                .addClass(isError ? 'error' : 'success')
                .html(message)
                .show();

            // Auto-hide after 5 seconds
            setTimeout(() => {
                this.$messageBox.fadeOut();
            }, 5000);
        }

        addToCart() {
            const items = [];

            this.$variantCheckboxes.filter(':checked').each((i, checkbox) => {
                const $checkbox = $(checkbox);
                const $row = $checkbox.closest('tr');
                const qty = parseInt($row.find('.qty-input').val(), 10) || 0;

                if (qty > 0) {
                    items.push({
                        product_id: $checkbox.data('product-id'),
                        variation_id: $checkbox.data('variation-id'),
                        quantity: qty,
                        attributes: $checkbox.data('attributes')
                    });
                }
            });

            debug('Adding to cart:', items);

            if (items.length === 0) {
                this.showMessage('Please select items and specify quantities.', true);
                return;
            }

            // Disable form during submission
            this.$form.find('input, button').prop('disabled', true);
            this.$submitButton.text('Adding to cart...');

            debug('Sending AJAX request');
            
            $.ajax({
                url: ppcData.ajax_url,
                type: 'POST',
                data: {
                    action: 'add_variants_to_cart',
                    nonce: ppcData.nonce,
                    items: items
                },
                success: (response) => {
                    debug('AJAX response:', response);
                    
                    if (response.success) {
                        this.showMessage(response.data.message);
                        
                        // Update cart count if WooCommerce cart fragments are available
                        if (typeof wc_cart_fragments_params !== 'undefined') {
                            $(document.body).trigger('wc_fragment_refresh');
                        }

                        // Reset form
                        this.$variantCheckboxes.prop('checked', false);
                        this.$form.find('.qty-input').prop('disabled', true).val(0);
                        this.$form.find('.qty-btn').prop('disabled', true);
                        this.updateSelectAllState();
                        this.updateSubmitButton();
                    } else {
                        this.showMessage(response.data.message, true);
                    }
                },
                error: (xhr, status, error) => {
                    debug('AJAX error:', { status, error });
                    this.showMessage(ppcData.i18n.error, true);
                },
                complete: () => {
                    debug('AJAX request complete');
                    // Re-enable form
                    this.$form.find('input:not(.qty-input[disabled]), button:not(.qty-btn[disabled])').prop('disabled', false);
                    this.$submitButton.text('Add Selected to Cart');
                    this.updateSubmitButton();
                }
            });
        }
    }

    // Initialize when document is fully loaded
    $(document).ready(() => {
        debug('Document ready, initializing VariantsTable');
        try {
            window.ppcVariantsTable = new VariantsTable();
        } catch (error) {
            console.error('[PPC Variants] Failed to initialize:', error);
        }
    });
}); 