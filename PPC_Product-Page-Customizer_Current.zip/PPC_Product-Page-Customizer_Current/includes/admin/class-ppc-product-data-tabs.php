<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Data_Tabs
{

    public function __construct()
    {
        // Only proceed if attachments feature is enabled
        if ('yes' === get_option('ppc_enable_pdf', 'no')) {
            add_filter('woocommerce_product_data_tabs', [$this, 'add_attachments_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'output_attachments_tab_content']);
            add_action('woocommerce_process_product_meta', [$this, 'save_attachments_tab_data']);
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        }
    }

    public function add_attachments_tab($tabs)
    {
        $tabs['ppc_attachments'] = [
            'label'    => __('Attachments', 'ppc'),
            'target'   => 'ppc_attachments_tab',
            'class'    => ['show_if_simple', 'show_if_variable'],
            'priority' => 70,
        ];
        return $tabs;
    }

    public function output_attachments_tab_content()
    {
        global $post;

        $pdf_url   = get_post_meta($post->ID, '_ppc_attachment_pdf_url', true);
        $pdf_title = get_post_meta($post->ID, '_ppc_attachment_pdf_title', true);
        $link_text = get_post_meta($post->ID, '_ppc_attachment_link_text', true);
?>
        <div id="ppc_attachments_tab" class="panel woocommerce_options_panel">
            <div class="options_group">

                <p class="form-field">
                    <label for="_ppc_attachment_pdf_url"><?php _e('PDF URL', 'ppc'); ?></label>
                    <input type="text" class="short" name="_ppc_attachment_pdf_url" id="_ppc_attachment_pdf_url" value="<?php echo esc_attr($pdf_url); ?>" />
                    <button type="button" class="button ppc-upload-pdf"><?php _e('Upload PDF', 'ppc'); ?></button>
                    <span class="description"><?php _e('Select or upload a PDF file.', 'ppc'); ?></span>
                </p>

                <?php
                woocommerce_wp_text_input([
                    'id'          => '_ppc_attachment_pdf_title',
                    'label'       => __('PDF Title', 'ppc'),
                    'description' => __('Optional title for the PDF.', 'ppc'),
                    'desc_tip'    => true,
                    'type'        => 'text',
                    'value'       => $pdf_title,
                ]);

                woocommerce_wp_text_input([
                    'id'          => '_ppc_attachment_link_text',
                    'label'       => __('Link Text', 'ppc'),
                    'description' => __('Text to display for the download link.', 'ppc'),
                    'desc_tip'    => true,
                    'type'        => 'text',
                    'value'       => $link_text,
                ]);
                ?>

            </div>
        </div>
<?php
    }

    public function save_attachments_tab_data($post_id)
    {
        if (isset($_POST['_ppc_attachment_pdf_url'])) {
            update_post_meta($post_id, '_ppc_attachment_pdf_url', esc_url_raw($_POST['_ppc_attachment_pdf_url']));
        }

        if (isset($_POST['_ppc_attachment_pdf_title'])) {
            update_post_meta($post_id, '_ppc_attachment_pdf_title', sanitize_text_field($_POST['_ppc_attachment_pdf_title']));
        }

        if (isset($_POST['_ppc_attachment_link_text'])) {
            update_post_meta($post_id, '_ppc_attachment_link_text', sanitize_text_field($_POST['_ppc_attachment_link_text']));
        }
    }

    public function enqueue_admin_scripts($hook)
    {
        if ($hook === 'post.php' || $hook === 'post-new.php') {
            wp_enqueue_script(
                'ppc-admin-pdf-uploader',
                plugins_url('../../assets/admin/Js/ppc-pdf-uploader-admin.js', __FILE__),
                ['jquery'],
                '1.0',
                true
            );
            wp_enqueue_media();
        }
    }
}

new PPC_Product_Data_Tabs();
