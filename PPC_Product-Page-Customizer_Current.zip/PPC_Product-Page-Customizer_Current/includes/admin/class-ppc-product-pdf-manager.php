<?php
// includes/admin/class-ppc-product-pdf-manager.php
if (!defined('ABSPATH')) exit;

class PPC_Product_PDF_Manager
{
    public function __construct()
    {
        add_action('add_meta_boxes', [$this, 'add_pdf_meta_box']);
        add_action('save_post', [$this, 'save_pdf_upload']);
    }

    public function add_pdf_meta_box()
    {
        add_meta_box(
            'ppc_product_pdf',
            __('Product User Guide PDF', 'product-page-customizer'),
            [$this, 'render_pdf_meta_box'],
            'product',
            'side',
            'default'
        );
    }

    public function render_pdf_meta_box($post)
    {
        $pdf = get_post_meta($post->ID, '_ppc_product_pdf', true);
        echo '<input type="hidden" name="ppc_pdf_nonce" value="' . wp_create_nonce('ppc_pdf_upload') . '">';
        echo '<input type="url" name="ppc_product_pdf" value="' . esc_attr($pdf) . '" style="width:100%;" placeholder="PDF URL or upload...">';
    }

    public function save_pdf_upload($post_id)
    {
        if (!isset($_POST['ppc_pdf_nonce']) || !wp_verify_nonce($_POST['ppc_pdf_nonce'], 'ppc_pdf_upload')) {
            return;
        }

        if (isset($_POST['ppc_product_pdf'])) {
            update_post_meta($post_id, '_ppc_product_pdf', esc_url_raw($_POST['ppc_product_pdf']));
        }
    }
}

new PPC_Product_PDF_Manager();
