<?php
// includes/admin/class-ppc-product-save-message-tab.php
if (!defined('ABSPATH')) exit;

class PPC_Product_Save_Message_Tab
{

    public function __construct()
    {
        if ('yes' === get_option('ppc_you_save_set_individual', 'no')) {
        add_filter('woocommerce_product_data_tabs', [$this, 'add_tab']);
        add_action('woocommerce_product_data_panels', [$this, 'add_fields']);
        add_action('woocommerce_process_product_meta', [$this, 'save_fields']);
        }
    }

    public function add_tab($tabs)
    {
        $tabs['ppc_save_message'] = [
            'label'  => __('Save Message', 'product-page-customizer'),
            'target' => 'ppc_save_message_product_data',
            'class'  => ['show_if_simple', 'show_if_variable'],
            'priority' => 90,
        ];
        return $tabs;
    }

    public function add_fields()
    {
        if ('yes' !== get_option('ppc_you_save_set_individual', 'no')) {
            return; // Do not display fields
        }
        global $post;

        $custom_message = get_post_meta($post->ID, '_ppc_individual_custom_msg', true);
        $prefix = get_post_meta($post->ID, '_ppc_individual_prefix', true);
        $position = get_post_meta($post->ID, '_ppc_individual_position', true);

?>
        <div id="ppc_save_message_product_data" class="panel woocommerce_options_panel">
            <div class="options_group">

                <?php
                // Custom Message
                woocommerce_wp_text_input([
                    'id' => '_ppc_individual_custom_msg',
                    'label' => __('Custom Message', 'product-page-customizer'),
                    'desc_tip' => true,
                    'description' => __('The full message to show, like "You Save ₹10".', 'product-page-customizer'),
                    'value' => $custom_message
                ]);

                // You Save prefix
                // woocommerce_wp_text_input([
                //     'id' => '_ppc_individual_prefix',
                //     'label' => __('Custom Message', 'product-page-customizer'),
                //     'desc_tip' => true,
                //     'description' => __('Text shown before the savings amount.', 'product-page-customizer'),
                //     'value' => $prefix ?: 'You Save'
                // ]);

                // Display position
                woocommerce_wp_select([
                    'id' => '_ppc_individual_position',
                    'label' => __('Display Position', 'product-page-customizer'),
                    'options' => [
                        'after_cart' => __('After Add to Cart Button (default)', 'product-page-customizer'),
                        'before_cart' => __('Before Add to Cart Button', 'product-page-customizer'),
                    ],
                    'value' => $position ?: 'after_cart'
                ]);
                ?>
            </div>
        </div>
<?php
    }

    public function save_fields($post_id)
    {
        if (isset($_POST['_ppc_individual_custom_msg'])) {
            update_post_meta($post_id, '_ppc_individual_custom_msg', sanitize_text_field($_POST['_ppc_individual_custom_msg']));
        }

        if (isset($_POST['_ppc_individual_prefix'])) {
            update_post_meta($post_id, '_ppc_individual_prefix', sanitize_text_field($_POST['_ppc_individual_prefix']));
        }

        if (isset($_POST['_ppc_individual_position'])) {
            update_post_meta($post_id, '_ppc_individual_position', sanitize_text_field($_POST['_ppc_individual_position']));
        }
    }
}

new PPC_Product_Save_Message_Tab();
