<?php

// includes/admin/class-ppc-product-min-max-fields.php
if (!defined('ABSPATH')) exit;

class PPC_Product_Min_Max_Quantity
{

    public function __construct()
    {
        // Always add product field hooks
        add_action('woocommerce_product_options_general_product_data', [$this, 'add_fields']);
        add_action('woocommerce_process_product_meta', [$this, 'save_fields']);

        // Only validate if global feature is enabled
        if ('yes' === get_option('ppc_enable_min_max_order', 'no')) {
            add_filter('woocommerce_add_to_cart_validation', [$this, 'validate_quantity'], 10, 3);
            add_filter('woocommerce_quantity_input_args', [$this, 'set_input_quantity_limits'], 10, 2);
        }
    }

    public function add_fields()
    {
        // Check if global feature is enabled
        if ('yes' !== get_option('ppc_enable_min_max_order', 'no')) {
            return; // Do not display fields
        }

        echo '<div class="options_group">';

        woocommerce_wp_text_input([
            'id' => '_ppc_min_qty',
            'label' => __('Minimum Quantity', 'product-page-customizer'),
            'desc_tip' => true,
            'description' => __('Set Minimum Quantity for this product.', 'product-page-customizer'),
            'type' => 'number',
            'custom_attributes' => ['min' => 1]
        ]);

        woocommerce_wp_text_input([
            'id' => '_ppc_max_qty',
            'label' => __('Maximum Quantity', 'product-page-customizer'),
            'desc_tip' => true,
            'description' => __('Set Maximum Quantity for this product.', 'product-page-customizer'),
            'type' => 'number',
            'custom_attributes' => ['min' => 1]
        ]);

        echo '</div>';
    }


    public function save_fields($post_id)
    {
        if (isset($_POST['_ppc_min_qty'])) {
            update_post_meta($post_id, '_ppc_min_qty', absint($_POST['_ppc_min_qty']));
        }

        if (isset($_POST['_ppc_max_qty'])) {
            update_post_meta($post_id, '_ppc_max_qty', absint($_POST['_ppc_max_qty']));
        }
    }

    public function validate_quantity($passed, $product_id, $quantity)
    {
        $min_qty = get_post_meta($product_id, '_ppc_min_qty', true);
        $max_qty = get_post_meta($product_id, '_ppc_max_qty', true);

        // Fallback to global settings if product-specific ones are not set
        if ($min_qty === '') {
            $min_qty = get_option('ppc_min_quantity', 1);
        }

        if ($max_qty === '') {
            $max_qty = get_option('ppc_max_quantity', 0);
        }

        $min_qty = (int) $min_qty;
        $max_qty = (int) $max_qty;

        if ($min_qty > 0 && $quantity < $min_qty) {
            wc_add_notice(sprintf(__('Minimum quantity for this product is %d.', 'product-page-customizer'), $min_qty), 'error');
            return false;
        }

        if ($max_qty > 0 && $quantity > $max_qty) {
            wc_add_notice(sprintf(__('Maximum quantity for this product is %d.', 'product-page-customizer'), $max_qty), 'error');
            return false;
        }

        return $passed;
    }

    public function set_input_quantity_limits($args, $product)
    {
        $product_id = $product->get_id();

        $min_qty = get_post_meta($product_id, '_ppc_min_qty', true);
        $max_qty = get_post_meta($product_id, '_ppc_max_qty', true);

        if ($min_qty === '') {
            $min_qty = get_option('ppc_min_quantity', 1);
        }

        if ($max_qty === '') {
            $max_qty = get_option('ppc_max_quantity', 0);
        }

        $args['min_value'] = (int) $min_qty;

        if ((int) $max_qty > 0) {
            $args['max_value'] = (int) $max_qty;
        }

        return $args;
    }
}

new PPC_Product_Min_Max_Quantity();
