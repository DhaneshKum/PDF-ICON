<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Variants_Display {
    public function __construct() {
        add_action('woocommerce_after_single_product_summary', [$this, 'render_variants_table'], 15);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_add_variants_to_cart', [$this, 'add_variants_to_cart']);
        add_action('wp_ajax_nopriv_add_variants_to_cart', [$this, 'add_variants_to_cart']);
    }

    public function enqueue_assets() {
        if (!is_product()) return;

        wp_enqueue_style(
            'ppc-variants-table',
            PPC_URL . 'assets/public/css/variants-table.css',
            [],
            PPC_VERSION
        );

        wp_enqueue_script(
            'ppc-variants',
            PPC_URL . 'assets/public/js/variants-table.js',
            ['jquery'],
            PPC_VERSION,
            true
        );

        wp_localize_script('ppc-variants', 'ppcData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('add_variants_to_cart'),
            'i18n' => [
                'added_to_cart' => __('Items added to cart successfully.', 'product-page-customizer'),
                'error' => __('Error adding items to cart.', 'product-page-customizer')
            ]
        ]);
    }

    public function add_variants_to_cart() {
        check_ajax_referer('add_variants_to_cart', 'nonce');

        $items = isset($_POST['items']) ? (array)$_POST['items'] : [];
        $success_count = 0;
        $errors = [];

        foreach ($items as $item) {
            if (empty($item['variation_id']) || empty($item['quantity'])) continue;

            $added = WC()->cart->add_to_cart(
                absint($item['product_id']),
                absint($item['quantity']),
                absint($item['variation_id']),
                wc_clean($item['attributes'])
            );

            if ($added) {
                $success_count++;
            } else {
                $errors[] = sprintf(
                    __('Failed to add variation #%s to cart.', 'product-page-customizer'),
                    $item['variation_id']
                );
            }
        }

        if ($success_count > 0) {
            wp_send_json_success([
                'message' => sprintf(
                    _n(
                        '%d item added to cart.',
                        '%d items added to cart.',
                        $success_count,
                        'product-page-customizer'
                    ),
                    $success_count
                ),
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'errors' => $errors
            ]);
        } else {
            wp_send_json_error([
                'message' => __('No items were added to cart.', 'product-page-customizer'),
                'errors' => $errors
            ]);
        }
    }

    public function render_variants_table() {
        global $product;

        if (!$product || !$product->is_type('variable')) return;

        $variations = $product->get_available_variations();
        if (empty($variations)) return;

        ?>
        <div class="ppc-variants-wrapper">
            <form class="ppc-variants-form">
                <table class="ppc-variants-table">
                    <thead>
                        <tr>
                            <th class="select-col">
                                <input type="checkbox" class="select-all" title="<?php esc_attr_e('Select all', 'product-page-customizer'); ?>">
                            </th>
                            <?php foreach ($product->get_variation_attributes() as $attr_name => $options): ?>
                                <th><?php echo wc_attribute_label($attr_name); ?></th>
                            <?php endforeach; ?>
                            <th><?php esc_html_e('Price', 'product-page-customizer'); ?></th>
                            <th><?php esc_html_e('Quantity', 'product-page-customizer'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($variations as $variation): 
                            $variation_obj = wc_get_product($variation['variation_id']);
                            if (!$variation_obj || !$variation_obj->is_purchasable()) continue;
                        ?>
                            <tr class="variant-row">
                                <td>
                                    <input type="checkbox" 
                                           class="variant-select" 
                                           data-price="<?php echo esc_attr($variation_obj->get_price()); ?>"
                                           data-variation-id="<?php echo esc_attr($variation['variation_id']); ?>"
                                           data-product-id="<?php echo esc_attr($product->get_id()); ?>"
                                           data-attributes="<?php echo esc_attr(json_encode($variation['attributes'])); ?>">
                                </td>
                                <?php foreach ($product->get_variation_attributes() as $attr_name => $options): 
                                    $attr_key = 'attribute_' . sanitize_title($attr_name);
                                    $attr_value = $variation['attributes'][$attr_key];
                                    $term = get_term_by('slug', $attr_value, $attr_name);
                                    $value = $term ? $term->name : $attr_value;
                                ?>
                                    <td><?php echo esc_html($value); ?></td>
                                <?php endforeach; ?>
                                <td class="price"><?php echo $variation_obj->get_price_html(); ?></td>
                                <td class="quantity">
                                    <div class="quantity-wrapper">
                                        <button type="button" class="qty-btn minus" disabled>−</button>
                                        <input type="number" 
                                               class="qty-input" 
                                               value="0" 
                                               min="1" 
                                               step="1"
                                               max="<?php echo esc_attr($variation_obj->get_max_purchase_quantity() === -1 ? 99 : $variation_obj->get_max_purchase_quantity()); ?>"
                                               disabled>
                                        <button type="button" class="qty-btn plus" disabled>+</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="ppc-variants-actions">
                    <button type="submit" class="button alt add-to-cart-button" disabled>
                        <?php esc_html_e('Add Selected to Cart', 'product-page-customizer'); ?>
                    </button>
                    <div class="message-box"></div>
                </div>
            </form>
        </div>
        <?php
    }
}

new PPC_Product_Variants_Display(); 