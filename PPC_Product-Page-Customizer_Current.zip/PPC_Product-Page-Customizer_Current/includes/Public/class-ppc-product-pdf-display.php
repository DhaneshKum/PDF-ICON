<?php
// includes/admin/class-ppc-product-pdf-display.php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PPC_Product_PDF_Display {

    public function __construct() {
        add_action( 'woocommerce_product_thumbnails', [ $this, 'display_product_pdf' ], 20 );
    }

    public function display_product_pdf() {
        global $post;

        if ( ! $post instanceof WP_Post ) {
            return;
        }

        $pdf_url   = get_post_meta( $post->ID, '_ppc_attachment_pdf_url', true );
        $pdf_title = get_post_meta( $post->ID, '_ppc_attachment_pdf_title', true );
        $link_text = get_post_meta( $post->ID, '_ppc_attachment_link_text', true );

        if ( empty( $pdf_url ) ) {
            return;
        }

        $icon_url = plugin_dir_url( __FILE__ ) . '../../assets/admin/images/pdf-icon-admin.png';

        echo '<div class="ppc-product-pdf" style="margin-top: 15px; display: flex; align-items: center; gap: 10px;">';

        if ( $icon_url ) {
            echo '<img src="' . esc_url( $icon_url ) . '" alt="PDF Icon" style="width: 45px; height: auto;">';
        }

        if ( $pdf_title ) {
            echo '<span style="font-weight: 550;">' . esc_html( $pdf_title ) . '</span>';
        }

        echo '<a href="' . esc_url( $pdf_url ) . '" target="_blank" class="button alt">';
        echo esc_html( $link_text ? $link_text : 'Download PDF' );
        echo '</a>';

        echo '</div>';
    }

}
new PPC_Product_PDF_Display();
