jQuery(function($) {
    'use strict';

    class VariantsTable {
        constructor() {
            // Cache DOM elements
            this.$form = $('.ppc-variants-form');
            this.$selectAll = this.$form.find('.select-all');
            this.$variantCheckboxes = this.$form.find('.variant-select');
            this.$submitButton = this.$form.find('.add-to-cart-button');
            this.$messageBox = this.$form.find('.message-box');

            this.bindEvents();
        }

        bindEvents() {
            // Handle individual variant selection
            this.$variantCheckboxes.on('change', (e) => {
                const $checkbox = $(e.target);
                const $row = $checkbox.closest('tr');
                const $qtyInput = $row.find('.qty-input');
                const $qtyButtons = $row.find('.qty-btn');

                if ($checkbox.is(':checked')) {
                    $qtyInput.prop('disabled', false).val(1);
                    $qtyButtons.prop('disabled', false);
                } else {
                    $qtyInput.prop('disabled', true).val(0);
                    $qtyButtons.prop('disabled', true);
                }

                this.updateSelectAllState();
                this.updateSubmitButton();
            });

            // Handle select all checkbox
            this.$selectAll.on('change', (e) => {
                const isChecked = $(e.target).is(':checked');
                
                this.$variantCheckboxes.each((i, checkbox) => {
                    const $checkbox = $(checkbox);
                    const $row = $checkbox.closest('tr');
                    const $qtyInput = $row.find('.qty-input');
                    const $qtyButtons = $row.find('.qty-btn');

                    $checkbox.prop('checked', isChecked);
                    $qtyInput.prop('disabled', !isChecked).val(isChecked ? 1 : 0);
                    $qtyButtons.prop('disabled', !isChecked);
                });

                this.updateSubmitButton();
            });

            // Handle quantity adjustments
            this.$form.on('click', '.qty-btn', (e) => {
                e.preventDefault();
                const $button = $(e.target);
                const $input = $button.closest('.quantity-wrapper').find('.qty-input');
                
                if ($input.prop('disabled')) return;

                const currentVal = parseInt($input.val(), 10) || 0;
                const min = parseInt($input.attr('min'), 10) || 1;
                const max = parseInt($input.attr('max'), 10) || 99;
                let newVal = currentVal;

                if ($button.hasClass('plus')) {
                    newVal = currentVal < max ? currentVal + 1 : max;
                } else if ($button.hasClass('minus')) {
                    newVal = currentVal > min ? currentVal - 1 : min;
                }

                if (newVal !== currentVal) {
                    $input.val(newVal).trigger('change');
                }
            });

            // Handle direct quantity input
            this.$form.on('change', '.qty-input', (e) => {
                const $input = $(e.target);
                if ($input.prop('disabled')) return;

                let val = parseInt($input.val(), 10) || 0;
                const min = parseInt($input.attr('min'), 10) || 1;
                const max = parseInt($input.attr('max'), 10) || 99;

                // Ensure value is within bounds
                val = Math.max(min, Math.min(val, max));
                $input.val(val);

                this.updateSubmitButton();
            });

            // Handle form submission
            this.$form.on('submit', (e) => {
                e.preventDefault();
                this.addToCart();
            });

            // Prevent form submission on enter key in quantity inputs
            this.$form.on('keypress', '.qty-input', (e) => {
                if (e.which === 13) {
                    e.preventDefault();
                    return false;
                }
            });
        }

        updateSelectAllState() {
            const totalCheckboxes = this.$variantCheckboxes.length;
            const checkedCheckboxes = this.$variantCheckboxes.filter(':checked').length;
            
            this.$selectAll.prop({
                checked: checkedCheckboxes > 0 && checkedCheckboxes === totalCheckboxes,
                indeterminate: checkedCheckboxes > 0 && checkedCheckboxes < totalCheckboxes
            });
        }

        updateSubmitButton() {
            let hasSelectedItems = false;

            this.$variantCheckboxes.each((i, checkbox) => {
                const $checkbox = $(checkbox);
                if ($checkbox.is(':checked')) {
                    const qty = parseInt($checkbox.closest('tr').find('.qty-input').val(), 10) || 0;
                    if (qty > 0) {
                        hasSelectedItems = true;
                        return false; // Break the loop
                    }
                }
            });

            this.$submitButton.prop('disabled', !hasSelectedItems);
        }

        showMessage(message, isError = false) {
            this.$messageBox
                .removeClass('success error')
                .addClass(isError ? 'error' : 'success')
                .html(message)
                .show();

            // Auto-hide after 5 seconds
            setTimeout(() => {
                this.$messageBox.fadeOut();
            }, 5000);
        }

        addToCart() {
            const items = [];

            this.$variantCheckboxes.filter(':checked').each((i, checkbox) => {
                const $checkbox = $(checkbox);
                const $row = $checkbox.closest('tr');
                const qty = parseInt($row.find('.qty-input').val(), 10) || 0;

                if (qty > 0) {
                    items.push({
                        product_id: $checkbox.data('product-id'),
                        variation_id: $checkbox.data('variation-id'),
                        quantity: qty,
                        attributes: $checkbox.data('attributes')
                    });
                }
            });

            if (items.length === 0) {
                this.showMessage('Please select items and specify quantities.', true);
                return;
            }

            // Disable form during submission
            this.$form.find('input, button').prop('disabled', true);
            this.$submitButton.text('Adding to cart...');

            $.ajax({
                url: ppcData.ajax_url,
                type: 'POST',
                data: {
                    action: 'add_variants_to_cart',
                    nonce: ppcData.nonce,
                    items: items
                },
                success: (response) => {
                    if (response.success) {
                        this.showMessage(response.data.message);
                        
                        // Update cart count if WooCommerce cart fragments are available
                        if (typeof wc_cart_fragments_params !== 'undefined') {
                            $(document.body).trigger('wc_fragment_refresh');
                        }

                        // Reset form
                        this.$variantCheckboxes.prop('checked', false);
                        this.$form.find('.qty-input').prop('disabled', true).val(0);
                        this.$form.find('.qty-btn').prop('disabled', true);
                        this.updateSelectAllState();
                        this.updateSubmitButton();
                    } else {
                        this.showMessage(response.data.message, true);
                    }
                },
                error: () => {
                    this.showMessage(ppcData.i18n.error, true);
                },
                complete: () => {
                    // Re-enable form
                    this.$form.find('input, button').prop('disabled', false);
                    this.$submitButton.text('Add Selected to Cart');
                    this.updateSubmitButton();
                }
            });
        }
    }

    // Initialize the variants table
    new VariantsTable();
}); 