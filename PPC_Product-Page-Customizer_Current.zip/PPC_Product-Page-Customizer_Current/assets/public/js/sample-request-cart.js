jQuery(document).ready(function($) {
    $('#sample-request-btn').on('click', function(e) {
        e.preventDefault();

        var $button = $(this);
        var product_id = $button.data('product_id');
        var nonce = $button.data('nonce');

        // Disable button
        $button.prop('disabled', true);

        // Add sample to cart via AJAX
        $.ajax({
            type: 'POST',
            url: ppcSampleRequest.ajaxurl,
            data: {
                action: 'add_sample_to_cart',
                product_id: product_id,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    // Redirect to cart page
                    window.location.href = response.data.cart_url;
                } else {
                    alert(response.data.message);
                    $button.prop('disabled', false);
                }
            },
            error: function() {
                alert('Error occurred. Please try again.');
                $button.prop('disabled', false);
            }
        });
    });
}); 