jQuery(document).ready(function ($) {
  // Enforce mutual exclusivity
  $('#ppc_you_save_set_individual').on('change', function () {
    if ($(this).is(':checked')) {
      $('#ppc_you_save_set_global').prop('checked', false).trigger('change');
    }
  });

  $('#ppc_you_save_set_global').on('change', function () {
    if ($(this).is(':checked')) {
      $('#ppc_you_save_set_individual').prop('checked', false);
    }
    toggleGlobalFields();
  });

  function toggleYouSaveFields() {
    const isEnabled = $('#ppc_enable_you_save').is(':checked');
    $('#ppc_you_save_set_individual').closest('tr').toggle(isEnabled);
    $('#ppc_you_save_set_global').closest('tr').toggle(isEnabled);
    toggleGlobalFields();
  }

  function toggleGlobalFields() {
    const isGlobal = $('#ppc_you_save_set_global').is(':checked') && $('#ppc_enable_you_save').is(':checked');
    $('.ppc_global_only').closest('tr').toggle(isGlobal);
  }

  toggleYouSaveFields();
  $('#ppc_enable_you_save').on('change', toggleYouSaveFields);
});
