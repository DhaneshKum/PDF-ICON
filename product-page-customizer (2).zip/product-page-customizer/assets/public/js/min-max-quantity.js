jQuery(document).ready(function($) {
    'use strict';

    // Handle variable products
    $('form.variations_form').each(function() {
        const $form = $(this);
        const $quantityInput = $form.find('.quantity input.qty');
        
        // When variation is found
        $form.on('found_variation', function(event, variation) {
            if (variation.min_qty !== undefined && variation.max_qty !== undefined) {
                // Update quantity input limits
                $quantityInput.attr('min', variation.min_qty)
                            .attr('max', variation.max_qty);
                
                // If current value is outside new limits, adjust it
                let currentVal = parseInt($quantityInput.val(), 10);
                if (currentVal < variation.min_qty) {
                    $quantityInput.val(variation.min_qty);
                } else if (currentVal > variation.max_qty) {
                    $quantityInput.val(variation.max_qty);
                }
            }
        });
        
        // When variation is reset
        $form.on('reset_data', function() {
            // Reset to default/global values
            const defaultMin = $quantityInput.data('min') || 1;
            const defaultMax = $quantityInput.data('max') || '';
            
            $quantityInput.attr('min', defaultMin)
                        .attr('max', defaultMax)
                        .val(defaultMin);
        });
    });
}); 