jQuery(document).ready(function ($) {
  // Function to show/hide the mode selection fields (Set Per Product and Set Globally)
  function toggleModeFields(show) {
    $('#ppc_you_save_set_individual, #ppc_you_save_set_global').closest('tr').toggle(show);
  }

  // Function to show/hide global settings fields
  function toggleGlobalFields(show) {
    $('.ppc_you_save_global_only').closest('tr').toggle(show);
  }

  // Handle main Enable checkbox
  $('#ppc_enable_you_save').on('change', function() {
    const isEnabled = $(this).is(':checked');
    toggleModeFields(isEnabled);
    
    // If disabling, also hide global fields and uncheck mode selections
    if (!isEnabled) {
      toggleGlobalFields(false);
      $('#ppc_you_save_set_individual, #ppc_you_save_set_global').prop('checked', false);
    } else {
      // If enabling and Set Globally is checked, show global fields
      if ($('#ppc_you_save_set_global').is(':checked')) {
        toggleGlobalFields(true);
      }
    }
  });

  // Handle Set Globally checkbox
  $('#ppc_you_save_set_global').on('change', function () {
    const isChecked = $(this).is(':checked');
    if (isChecked) {
      $('#ppc_you_save_set_individual').prop('checked', false);
      toggleGlobalFields(true);
    } else {
      toggleGlobalFields(false);
    }
  });

  // Handle Set Per Product checkbox
  $('#ppc_you_save_set_individual').on('change', function () {
    if ($(this).is(':checked')) {
      $('#ppc_you_save_set_global').prop('checked', false);
      toggleGlobalFields(false);
    }
  });

  // Initial state setup
  function initializeState() {
    const isEnabled = $('#ppc_enable_you_save').is(':checked');
    const isGlobalEnabled = $('#ppc_you_save_set_global').is(':checked');
    
    toggleModeFields(isEnabled);
    toggleGlobalFields(isEnabled && isGlobalEnabled);
  }

  // Run initial state setup
  initializeState();

  // Add CSS for smooth transitions
  $('<style>')
    .prop('type', 'text/css')
    .html(`
      .ppc_you_save_global_only {
        transition: opacity 0.3s ease-in-out;
      }
      tr:has(.ppc_you_save_global_only) {
        transition: all 0.3s ease-in-out;
      }
    `)
    .appendTo('head');
});
