jQuery(document).ready(function ($) {
    function toggleSampleLabelField() {
        const isEnabled = $('#enable_sample_request').is(':checked');
        $('#sample_button_label').closest('tr').toggle(isEnabled);
    }

    toggleSampleLabelField();

    // Toggle when checkbox changes
    $('#enable_sample_request').on('change', toggleSampleLabelField);
}); 