<?php

// includes/admin/class-ppc-product-min-max-fields.php
if (!defined('ABSPATH')) exit;

class PPC_Product_Min_Max_Quantity
{
    public function __construct()
    {
        // Only validate if global feature is enabled
        if ('yes' === get_option('ppc_enable_min_max_order', 'no')) {
            // Frontend validation hooks
            add_filter('woocommerce_add_to_cart_validation', [$this, 'validate_quantity'], 10, 3);
            add_filter('woocommerce_quantity_input_args', [$this, 'set_input_quantity_limits'], 10, 2);
            add_filter('woocommerce_available_variation', [$this, 'add_min_max_to_variation_data'], 10, 3);

            // Admin product tab hooks
            add_filter('woocommerce_product_data_tabs', [$this, 'add_min_max_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'add_min_max_fields']);
            add_action('woocommerce_process_product_meta', [$this, 'save_min_max_fields']);

            // Enqueue frontend scripts
            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        }
    }

    /**
     * Add Min/Max Quantity tab to Product Data tabs
     */
    public function add_min_max_tab($tabs) {
        $tabs['ppc_min_max'] = [
            'label'    => __('Min/Max Quantity', 'product-page-customizer'),
            'target'   => 'ppc_min_max_product_data',
            'class'    => ['show_if_simple', 'show_if_variable'],
            'priority' => 85,
        ];
        return $tabs;
    }

    /**
     * Add fields to Min/Max Quantity tab
     */
    public function add_min_max_fields() {
        global $post;

        $global_min = get_option('ppc_min_quantity', 1);
        $global_max = get_option('ppc_max_quantity', 10);

        echo '<div id="ppc_min_max_product_data" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';
        
        echo '<p class="form-field">';
        echo '<label>' . __('Global Settings', 'product-page-customizer') . '</label>';
        echo '<span class="description">' . sprintf(__('Global Min: %d, Global Max: %d', 'product-page-customizer'), $global_min, $global_max) . '</span>';
        echo '</p>';

        // Minimum Quantity field
        woocommerce_wp_text_input([
            'id'          => '_ppc_min_qty',
            'label'       => __('Minimum Quantity', 'product-page-customizer'),
            'desc_tip'    => true,
            'description' => __('Set custom Minimum Quantity for this product. Leave empty to use global setting.', 'product-page-customizer'),
            'type'        => 'number',
            'custom_attributes' => [
                'min'  => '1',
                'step' => '1'
            ]
        ]);

        // Maximum Quantity field
        woocommerce_wp_text_input([
            'id'          => '_ppc_max_qty',
            'label'       => __('Maximum Quantity', 'product-page-customizer'),
            'desc_tip'    => true,
            'description' => __('Set custom Maximum Quantity for this product. Leave empty to use global setting.', 'product-page-customizer'),
            'type'        => 'number',
            'custom_attributes' => [
                'min'  => '1',
                'step' => '1'
            ]
        ]);

        echo '</div>';
        echo '</div>';
    }

    /**
     * Save Min/Max Quantity fields
     */
    public function save_min_max_fields($post_id) {
        // Get the product
        $product = wc_get_product($post_id);
        if (!$product) {
            return;
        }

        // Save minimum quantity
        if (isset($_POST['_ppc_min_qty'])) {
            $min_qty = absint($_POST['_ppc_min_qty']);
            if ($min_qty < 1) $min_qty = 1;
            update_post_meta($post_id, '_ppc_min_qty', $min_qty);
        }

        // Save maximum quantity
        if (isset($_POST['_ppc_max_qty'])) {
            $max_qty = absint($_POST['_ppc_max_qty']);
            if ($max_qty < 1) $max_qty = 1;
            update_post_meta($post_id, '_ppc_max_qty', $max_qty);
        }

        // If this is a variable product, apply settings to all variations
        if ($product->is_type('variable')) {
            $variations = $product->get_children();
            foreach ($variations as $variation_id) {
                if (isset($_POST['_ppc_min_qty'])) {
                    update_post_meta($variation_id, '_ppc_min_qty', $min_qty);
                }
                if (isset($_POST['_ppc_max_qty'])) {
                    update_post_meta($variation_id, '_ppc_max_qty', $max_qty);
                }
            }
        }
    }

    /**
     * Get min quantity for a product
     */
    private function get_min_quantity($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return get_option('ppc_min_quantity', 1);
        }

        // Get individual min quantity
        $individual_min = get_post_meta($product_id, '_ppc_min_qty', true);
        
        // If this is a variation and has no individual setting, check the parent
        if ($product->is_type('variation') && empty($individual_min)) {
            $parent_id = $product->get_parent_id();
            $individual_min = get_post_meta($parent_id, '_ppc_min_qty', true);
        }

        if (!empty($individual_min)) {
            return $individual_min;
        }

        return get_option('ppc_min_quantity', 1);
    }

    /**
     * Get max quantity for a product
     */
    private function get_max_quantity($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return get_option('ppc_max_quantity', 10);
        }

        // Get individual max quantity
        $individual_max = get_post_meta($product_id, '_ppc_max_qty', true);
        
        // If this is a variation and has no individual setting, check the parent
        if ($product->is_type('variation') && empty($individual_max)) {
            $parent_id = $product->get_parent_id();
            $individual_max = get_post_meta($parent_id, '_ppc_max_qty', true);
        }

        if (!empty($individual_max)) {
            return $individual_max;
        }

        return get_option('ppc_max_quantity', 10);
    }

    /**
     * Validate quantity against min/max limits
     */
    public function validate_quantity($passed, $product_id, $quantity)
    {
        // Get the product
        $product = wc_get_product($product_id);
        if (!$product) {
            return $passed;
        }

        // For variable products, we need to check the variation
        if ($product->is_type('variable')) {
            // Get the variation ID from the cart item data
            $variation_id = isset($_POST['variation_id']) ? absint($_POST['variation_id']) : 0;
            if ($variation_id) {
                $product_id = $variation_id;
            }
        }

        // Get min/max quantities for this product/variation
        $min = $this->get_min_quantity($product_id);
        $max = $this->get_max_quantity($product_id);

        // First check if the quantity being added is valid
        if ($quantity < $min) {
            wc_add_notice(
                sprintf(__('Minimum quantity for this product is %d.', 'product-page-customizer'), $min),
                'error'
            );
            return false;
        }

        // Get current cart quantity for this product/variation
        $cart = WC()->cart;
        $current_cart_qty = 0;
        if ($cart) {
            $cart_items = $cart->get_cart();
            foreach ($cart_items as $cart_item) {
                if ($cart_item['product_id'] == $product_id || 
                    (isset($cart_item['variation_id']) && $cart_item['variation_id'] == $product_id)) {
                    $current_cart_qty += $cart_item['quantity'];
                }
            }
        }

        // Calculate total quantity after adding new items
        $total_qty = $current_cart_qty + $quantity;

        // Check if total quantity exceeds maximum
        if ($total_qty > $max) {
            $remaining_qty = $max - $current_cart_qty;
            if ($remaining_qty <= 0) {
                wc_add_notice(
                    sprintf(__('Maximum quantity limit (%d) reached for this product.', 'product-page-customizer'), $max),
                    'error'
                );
            } else {
                wc_add_notice(
                    sprintf(__('Cannot add %d items. Maximum quantity is %d. You can add %d more.', 'product-page-customizer'), 
                        $quantity, $max, $remaining_qty),
                    'error'
                );
            }
            return false;
        }

        return $passed;
    }

    /**
     * Set quantity input limits
     */
    public function set_input_quantity_limits($args, $product)
    {
        $product_id = $product->get_id();

        // For variable products, check if we're dealing with a variation
        if ($product->is_type('variable')) {
            // Try to get variation ID from POST data or other contexts
            $variation_id = isset($_POST['variation_id']) ? absint($_POST['variation_id']) : 0;
            
            // Allow other plugins/themes to provide variation ID
            $variation_id = apply_filters('ppc_get_variation_id_for_quantity_limits', $variation_id, $product);
            
            // If we have a variation ID, use that instead of the parent product ID
            if ($variation_id) {
                $product_id = $variation_id;
            }
        }

        $min = $this->get_min_quantity($product_id);
        $max = $this->get_max_quantity($product_id);

        $args['min_value'] = $min;
        $args['max_value'] = $max;

        return $args;
    }

    /**
     * Add min/max quantity data to variation data
     */
    public function add_min_max_to_variation_data($variation_data, $product, $variation) {
        if (!$variation) {
            return $variation_data;
        }

        $variation_id = $variation->get_id();
        
        // Get min/max quantities for this variation
        $min = $this->get_min_quantity($variation_id);
        $max = $this->get_max_quantity($variation_id);

        // Add to variation data
        $variation_data['min_qty'] = $min;
        $variation_data['max_qty'] = $max;

        return $variation_data;
    }

    /**
     * Enqueue frontend scripts
     */
    public function enqueue_scripts() {
        if (is_product()) {
            wp_enqueue_script(
                'ppc-min-max-quantity',
                PPC_URL . 'assets/public/js/min-max-quantity.js',
                ['jquery'],
                PPC_VERSION,
                true
            );
        }
    }
}

new PPC_Product_Min_Max_Quantity();
