<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Variants_Display {
    private $table_rendered = false;

    public function __construct() {
        // Hook into position after product images
        add_action('woocommerce_after_single_product_summary', [$this, 'render_variants_table'], 5);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_add_variants_to_cart', [$this, 'add_variants_to_cart']);
        add_action('wp_ajax_nopriv_add_variants_to_cart', [$this, 'add_variants_to_cart']);
    }

    public function enqueue_assets() {
        if (!is_product()) return;

        global $post;
        $product = wc_get_product($post);
        if (!$product || !$product->is_type('variable')) return;

        // Enqueue WooCommerce scripts first
        wp_enqueue_script('wc-add-to-cart');
        wp_enqueue_script('wc-add-to-cart-variation');

        wp_enqueue_style(
            'ppc-variants-table',
            PPC_URL . 'assets/public/css/variants-table.css',
            [],
            PPC_VERSION
        );

        wp_enqueue_script(
            'ppc-variants',
            PPC_URL . 'assets/public/js/variants-table.js',
            ['jquery', 'wc-add-to-cart', 'wc-add-to-cart-variation'],
            PPC_VERSION,
            true
        );

        // Pass necessary data to JavaScript
        wp_localize_script('ppc-variants', 'ppcData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('add_variants_to_cart'),
            'product_id' => $product->get_id(),
            'i18n' => [
                'added_to_cart' => __('Items added to cart successfully.', 'product-page-customizer'),
                'error' => __('Error adding items to cart.', 'product-page-customizer'),
                'select_options' => __('Please select some product options before adding to cart.', 'product-page-customizer'),
                'out_of_stock' => __('Sorry, this product is unavailable.', 'product-page-customizer')
            ]
        ]);
    }

    public function add_variants_to_cart() {
        check_ajax_referer('add_variants_to_cart', 'nonce');

        $items = isset($_POST['items']) ? (array)$_POST['items'] : [];
        $success_count = 0;
        $errors = [];

        foreach ($items as $item) {
            if (empty($item['variation_id']) || empty($item['quantity'])) {
                continue;
            }

            $variation_id = absint($item['variation_id']);
            $product_id = absint($item['product_id']);
            $quantity = absint($item['quantity']);
            $variation = wc_get_product($variation_id);

            // Validate variation
            if (!$variation || !$variation->is_purchasable() || !$variation->is_in_stock()) {
                $errors[] = sprintf(
                    __('Variation #%s is not available.', 'product-page-customizer'),
                    $variation_id
                );
                continue;
            }

            // Validate quantity
            $max_qty = $variation->get_max_purchase_quantity();
            if ($max_qty > 0 && $quantity > $max_qty) {
                $quantity = $max_qty;
            }

            // Add to cart
            $added = WC()->cart->add_to_cart(
                $product_id,
                $quantity,
                $variation_id,
                wc_clean($item['attributes'])
            );

            if ($added) {
                $success_count++;
            } else {
                $errors[] = sprintf(
                    __('Failed to add variation #%s to cart.', 'product-page-customizer'),
                    $variation_id
                );
            }
        }

        if ($success_count > 0) {
            wp_send_json_success([
                'message' => sprintf(
                    _n(
                        '%d item added to cart.',
                        '%d items added to cart.',
                        $success_count,
                        'product-page-customizer'
                    ),
                    $success_count
                ),
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_total(),
                'errors' => $errors
            ]);
        } else {
            wp_send_json_error([
                'message' => __('No items were added to cart.', 'product-page-customizer'),
                'errors' => $errors
            ]);
        }
    }

    public function render_variants_table() {
        global $product;

        // Prevent multiple rendering
        if ($this->table_rendered) {
            return;
        }

        if (!$product || !$product->is_type('variable')) {
            return;
        }

        // Specific debug for product 317
        $is_target_product = ($product->get_id() == 317);
        if ($is_target_product) {
            error_log('PPC Debug - Processing Product 317');
            
            // Debug raw attributes
            $raw_attributes = $product->get_attributes();
            error_log('PPC Debug - Raw Attributes: ' . print_r($raw_attributes, true));
        }

        // Check if variants table is enabled globally or individually
        $enable_global = get_option('ppc_variants_set_global') === 'yes' && get_option('ppc_enable_variants_table') === 'yes';
        $enable_individual = get_option('ppc_variants_set_individual') === 'yes';

        if ($enable_individual) {
            // Check individual product setting
            if (get_post_meta($product->get_id(), '_ppc_enable_variants_table', true) !== 'yes') {
                return;
            }
        } elseif (!$enable_global) {
            return;
        }

        // Get ALL variations first
        $all_variations = [];
        $variation_ids = $product->get_children();
        
        foreach ($variation_ids as $variation_id) {
            $variation = wc_get_product($variation_id);
            if (!$variation || !$variation->is_purchasable()) continue;

            // Get all attributes for this variation
            $variation_attributes = $variation->get_variation_attributes();
            $variation_data = [
                'variation_id' => $variation_id,
                'attributes' => $variation_attributes,
                'price_html' => $variation->get_price_html(),
                'max_qty' => $variation->get_max_purchase_quantity(),
                'stock_qty' => $variation->get_stock_quantity(),
                'is_in_stock' => $variation->is_in_stock(),
                'display_values' => []
            ];

            // Get display values for each attribute
            foreach ($variation_attributes as $attr_name => $attr_value) {
                $taxonomy = str_replace('attribute_', '', $attr_name);
                if (taxonomy_exists($taxonomy)) {
                    $term = get_term_by('slug', $attr_value, $taxonomy);
                    $variation_data['display_values'][$attr_name] = $term ? $term->name : $attr_value;
                } else {
                    $variation_data['display_values'][$attr_name] = $attr_value;
                }
            }

            $all_variations[] = $variation_data;
        }

        error_log('PPC Debug - All collected variations: ' . print_r($all_variations, true));

        if (empty($all_variations)) {
            return;
        }

        // Get all available attributes
        $all_attributes = [];
        foreach ($all_variations as $variation) {
            foreach ($variation['attributes'] as $attr_name => $attr_value) {
                if (!isset($all_attributes[$attr_name])) {
                    $taxonomy = str_replace('attribute_', '', $attr_name);
                    $all_attributes[$attr_name] = [
                        'name' => wc_attribute_label($taxonomy),
                        'values' => []
                    ];
                }
                if (!empty($attr_value)) {
                    $all_attributes[$attr_name]['values'][$attr_value] = $variation['display_values'][$attr_name];
                }
            }
        }

        error_log('PPC Debug - All collected attributes: ' . print_r($all_attributes, true));

        // Get global settings
        $global_message = get_option('ppc_variants_global_msg', '');
        
        ?>
        <div class="ppc-variants-wrapper">
            <?php if ($enable_global && !empty($global_message)): ?>
                <div class="ppc-variants-global-message"><?php echo esc_html($global_message); ?></div>
            <?php endif; ?>
            <form class="ppc-variants-form" method="post">
                <?php wp_nonce_field('add_variants_to_cart', 'variants_nonce'); ?>
                <table class="ppc-variants-table">
                    <thead>
                        <tr>
                            <th class="select-col">
                                <input type="checkbox" class="select-all" title="<?php esc_attr_e('Select all', 'product-page-customizer'); ?>">
                            </th>
                            <?php foreach ($all_attributes as $attr_key => $attr_data): ?>
                                <th><?php echo esc_html($attr_data['name']); ?></th>
                            <?php endforeach; ?>
                            <th><?php esc_html_e('Price', 'product-page-customizer'); ?></th>
                            <th><?php esc_html_e('Quantity', 'product-page-customizer'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_variations as $variation): 
                            $max_qty = $variation['max_qty'];
                            $max_qty = $max_qty < 0 ? 99 : $max_qty;
                            
                            // Get min/max quantities for this variation
                            $min_max_handler = new PPC_Product_Min_Max_Quantity();
                            $min_qty = $min_max_handler->get_min_quantity($variation['variation_id']);
                            $max_qty = min($max_qty, $min_max_handler->get_max_quantity($variation['variation_id']));
                            
                            // If stock management is enabled, ensure max quantity doesn't exceed stock
                            $max_qty = $variation['stock_qty'] !== null ? min($max_qty, $variation['stock_qty']) : $max_qty;
                        ?>
                            <tr class="variant-row<?php echo !$variation['is_in_stock'] ? ' out-of-stock' : ''; ?>">
                                <td>
                                    <input type="checkbox" 
                                           class="variant-select" 
                                           name="variant_selected[]"
                                           value="<?php echo esc_attr($variation['variation_id']); ?>"
                                           <?php disabled(!$variation['is_in_stock']); ?>
                                           data-price="<?php echo esc_attr(wc_get_product($variation['variation_id'])->get_price()); ?>"
                                           data-variation-id="<?php echo esc_attr($variation['variation_id']); ?>"
                                           data-product-id="<?php echo esc_attr($product->get_id()); ?>"
                                           data-attributes="<?php echo esc_attr(json_encode($variation['attributes'])); ?>">
                                </td>
                                <?php foreach ($all_attributes as $attr_key => $attr_data): 
                                    $attr_value = isset($variation['display_values'][$attr_key]) ? $variation['display_values'][$attr_key] : '';
                                ?>
                                    <td><?php echo esc_html($attr_value); ?></td>
                                <?php endforeach; ?>
                                <td class="price"><?php echo $variation['price_html']; ?></td>
                                <td class="quantity">
                                    <div class="quantity-wrapper">
                                        <button type="button" 
                                                class="qty-btn minus" 
                                                tabindex="0"
                                                <?php disabled(!$variation['is_in_stock']); ?>
                                                aria-label="<?php esc_attr_e('Decrease quantity', 'product-page-customizer'); ?>" 
                                                disabled>−</button>
                                        <input type="number" 
                                               class="qty-input" 
                                               name="quantity[<?php echo esc_attr($variation['variation_id']); ?>]"
                                               value="0" 
                                               min="<?php echo esc_attr($min_qty); ?>" 
                                               max="<?php echo esc_attr($max_qty); ?>"
                                               step="1"
                                               pattern="[0-9]*"
                                               inputmode="numeric"
                                               <?php disabled(!$variation['is_in_stock']); ?>
                                               aria-label="<?php esc_attr_e('Product quantity', 'product-page-customizer'); ?>"
                                               disabled>
                                        <button type="button" 
                                                class="qty-btn plus" 
                                                tabindex="0"
                                                <?php disabled(!$variation['is_in_stock']); ?>
                                                aria-label="<?php esc_attr_e('Increase quantity', 'product-page-customizer'); ?>" 
                                                disabled>+</button>
                                    </div>
                                    <?php if (!$variation['is_in_stock']): ?>
                                        <p class="stock out-of-stock"><?php esc_html_e('Out of stock', 'product-page-customizer'); ?></p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="ppc-variants-actions">
                    <button type="submit" class="button alt add-to-cart-button" disabled>
                        <?php esc_html_e('Add Selected to Cart', 'product-page-customizer'); ?>
                    </button>
                    <div class="message-box"></div>
                </div>
            </form>
        </div>
        <?php
        
        $this->table_rendered = true;
    }
}

new PPC_Product_Variants_Display(); 